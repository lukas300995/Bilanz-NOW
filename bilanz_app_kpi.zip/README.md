# 📊 Bilanz App (Demo)

Streamlit-App zur Bilanzanalyse mit Dummy-Daten oder Datei-Upload.

## Login
- Kunde: kunde / kunde123
- Steuerberater: berater / berater123
- Bank: bank / bank123
