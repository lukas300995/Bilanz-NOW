
import streamlit as st
import pandas as pd

st.set_page_config(page_title="Bilanz App", layout="wide")

# Demo-Login
users = {
    "kunde": "kunde123",
    "berater": "berater123",
    "bank": "bank123"
}

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.role = None

st.title("📊 Bilanz App (Demo)")

if not st.session_state.logged_in:
    st.subheader("Login")
    user = st.text_input("Benutzername")
    pw = st.text_input("Passwort", type="password")
    if st.button("Login"):
        if user in users and users[user] == pw:
            st.session_state.logged_in = True
            st.session_state.role = user
            st.success(f"Willkommen, {user}!")
        else:
            st.error("Ungültige Zugangsdaten.")
else:
    st.sidebar.write(f"👤 Eingeloggt als: {st.session_state.role}")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.role = None
        st.experimental_rerun()

    role = st.session_state.role

    if role == "kunde":
        st.header("📂 Upload von Bilanzdaten")
        uploaded = st.file_uploader("Datei hochladen", type=["csv","xlsx","xml","pdf"])
        if uploaded:
            st.success(f"Datei {uploaded.name} wurde hochgeladen.")
            # Dummy-Anzeige
            st.write("👉 Automatische Analyse würde hier passieren.")
    elif role == "berater":
        st.header("👨‍💼 Steuerberater-Bereich")
        st.info("Hier erscheinen die Daten der freigegebenen Kunden.")
    elif role == "bank":
        st.header("🏦 Bank-Bereich")
        st.info("Hier erscheinen die Daten der freigegebenen Kunden.")
