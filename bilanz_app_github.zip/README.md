# 📊 Bilanz App (Demo)

Streamlit-App zur Bilanzanalyse.
