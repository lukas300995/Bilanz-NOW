
import streamlit as st
import pandas as pd
import numpy as np
import json, os, io, datetime
import xml.etree.ElementTree as ET

# --- Config / files ---
USERS = {
    "kunde": {"password": "kunde123", "role": "kunde", "name": "Muster Kunde"},
    "berater": {"password": "berater123", "role": "steuerberater", "name": "Muster Berater"},
    "bank": {"password": "bank123", "role": "bank", "name": "Muster Bank"}
}

ACCESS_FILE = "access.json"      # stores freigaben
DATA_FILE = "bilanzdata.csv"    # stored table
META_FILE = "meta.json"         # stores last_upload, notifications

REMINDER_DAYS = 90  # days without upload triggers reminder banner to customer

# Ensure files exist
if not os.path.exists(ACCESS_FILE):
    with open(ACCESS_FILE, "w") as f:
        json.dump({"kunde": {"berater": False, "bank": False}}, f)

if not os.path.exists(META_FILE):
    with open(META_FILE, "w") as f:
        json.dump({"last_upload": None, "notifications": []}, f)

# --- Helpers ---
def load_access():
    with open(ACCESS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_access(data):
    with open(ACCESS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def load_meta():
    with open(META_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def save_meta(data):
    with open(META_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def save_data(df):
    df.to_csv(DATA_FILE, index=False)

def load_data():
    if os.path.exists(DATA_FILE):
        return pd.read_csv(DATA_FILE)
    return None

# Simple XML parser tolerant to tag names
def _norm(s: str) -> str:
    return (s or "").strip().lower().replace("ä","ae").replace("ö","oe").replace("ü","ue").replace("ß","ss").replace(" ", "").replace("-", "").replace(".", "")

ALL_COLS = ["Jahr","Bilanzsumme","Anlagevermögen","Umlaufvermögen","Liquide Mittel","Forderungen","Vorräte","Eigenkapital","Langfristiges Fremdkapital","Kurzfristiges Fremdkapital","Umsatz","EBIT"]

def parse_xml_to_df(uploaded_file) -> pd.DataFrame:
    data = uploaded_file.read()
    uploaded_file.seek(0)
    try:
        root = ET.fromstring(data)
    except ET.ParseError as e:
        raise ValueError(f"XML nicht lesbar: {e}")

    rows = []
    # try find repeated 'row'-like elements
    for elem in root.iter():
        children = list(elem)
        if len(children) >= 2:
            row = {}
            for child in children:
                key = _norm(child.tag)
                text = (child.text or "").strip() or child.get("value") or ""
                # try match to known columns by normalized name
                for col in ALL_COLS:
                    if _norm(col) in key:
                        row[col] = text
                        break
            # also attributes
            for k,v in elem.attrib.items():
                for col in ALL_COLS:
                    if _norm(col) in _norm(k):
                        row[col] = v
            if row:
                rows.append(row)
    if rows:
        df = pd.DataFrame(rows)
    else:
        # fallback: flatten and take first occurrence
        flat = {}
        for elem in root.iter():
            key = _norm(elem.tag)
            text = (elem.text or "").strip() or elem.get("value") or ""
            for col in ALL_COLS:
                if _norm(col) in key and col not in flat:
                    flat[col] = text
            for k,v in elem.attrib.items():
                for col in ALL_COLS:
                    if _norm(col) in _norm(k) and col not in flat:
                        flat[col] = v
        if not flat:
            raise ValueError("Keine passenden Felder im XML gefunden.")
        df = pd.DataFrame([flat])

    # coerce numeric where appropriate
    for c in df.columns:
        if c != "Jahr":
            df[c] = pd.to_numeric(df[c], errors="coerce")
    if "Jahr" in df.columns:
        try:
            df["Jahr"] = pd.to_numeric(df["Jahr"], errors="ignore")
        except Exception:
            pass
    # ensure columns exist
    for c in ALL_COLS:
        if c not in df.columns:
            df[c] = pd.NA
    # reorder
    cols = [c for c in ["Jahr"] + ALL_COLS if c in df.columns]
    df = df[cols]
    return df

def parse_pdf_to_df(uploaded_file) -> pd.DataFrame:
    # Best-effort: try tabula (Java required) then pdfplumber (pure python) as fallback.
    # If neither available, raise informative error.
    try:
        import tabula
        uploaded_file.seek(0)
        import tempfile
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        tmp.write(uploaded_file.read())
        tmp.flush()
        tmp.close()
        dfs = tabula.read_pdf(tmp.name, pages="all", multiple_tables=True)
        if dfs:
            df = dfs[0]
            for d in dfs:
                if d.shape[1] > df.shape[1]:
                    df = d
            return df
    except Exception:
        pass

    try:
        import pdfplumber
        uploaded_file.seek(0)
        import tempfile
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
        tmp.write(uploaded_file.read())
        tmp.flush()
        tmp.close()
        with pdfplumber.open(tmp.name) as pdf:
            tables = []
            for page in pdf.pages:
                for tbl in page.extract_tables():
                    try:
                        df = pd.DataFrame(tbl[1:], columns=tbl[0])
                        tables.append(df)
                    except Exception:
                        continue
            if tables:
                df = max(tables, key=lambda d: d.shape[1])
                return df
    except Exception:
        pass

    raise ValueError("PDF-Parsing nicht möglich. Bitte tabula-py (Java) oder pdfplumber installieren, oder laden Sie CSV/XLSX/XML hoch.")

# KPI calculation (same logic as before)
def calculate_kpis(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    # ensure numeric for KPI columns
    cols = ["Anlagevermögen","Umlaufvermögen","Liquide Mittel","Forderungen","Vorräte","Eigenkapital","Langfristiges Fremdkapital","Kurzfristiges Fremdkapital","Bilanzsumme"]
    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
        else:
            df[c] = np.nan

    df["Fremdkapital"] = df[["Langfristiges Fremdkapital","Kurzfristiges Fremdkapital"]].sum(axis=1, min_count=1)
    df["Bilanzsumme_calc"] = df[["Eigenkapital","Fremdkapital"]].sum(axis=1, min_count=1)
    df["Bilanzsumme_final"] = df["Bilanzsumme"].fillna(df["Bilanzsumme_calc"])

    df["Working Capital"] = df["Umlaufvermögen"] - df["Kurzfristiges Fremdkapital"]

    df["Liquidität 3. Grades"] = df["Umlaufvermögen"] / df["Kurzfristiges Fremdkapital"]
    df["Liquidität 2. Grades"] = (df["Liquide Mittel"].fillna(0) + df["Forderungen"].fillna(0)) / df["Kurzfristiges Fremdkapital"]
    df["Liquidität 1. Grades"] = df["Liquide Mittel"] / df["Kurzfristiges Fremdkapital"]

    df["Eigenkapitalquote"] = df["Eigenkapital"] / df["Bilanzsumme_final"]
    df["Fremdkapitalquote"] = df["Fremdkapital"] / df["Bilanzsumme_final"]
    df["Verschuldungsgrad"] = df["Fremdkapital"] / df["Eigenkapital"]

    av = df["Anlagevermögen"].fillna(df.get("Langfristiges Vermögen", np.nan))
    df["Anlagendeckungsgrad I"] = df["Eigenkapital"] / av
    df["Anlagendeckungsgrad II"] = (df["Eigenkapital"] + df["Langfristiges Fremdkapital"]) / av

    return df

# --- Streamlit UI ---
st.set_page_config(page_title="Bilanz-App (Freigaben & Notifications)", layout="wide")

st.sidebar.title("Login")
if "user" not in st.session_state:
    st.session_state.user = None

username = st.sidebar.text_input("Benutzername")
password = st.sidebar.text_input("Passwort", type="password")
if st.sidebar.button("Login"):
    if username in USERS and USERS[username]["password"] == password:
        st.session_state.user = {"username": username, "role": USERS[username]["role"], "display": USERS[username]["name"]}
        st.sidebar.success(f"Angemeldet: {USERS[username]['name']} ({USERS[username]['role']})")
    else:
        st.sidebar.error("Ungültige Zugangsdaten")

if st.session_state.user is None:
    st.info("Bitte einloggen (Demo-Accounts vorhanden).")
    st.sidebar.info("Demo: kunde/kunde123 · berater/berater123 · bank/bank123")
    st.stop()

user = st.session_state.user
access = load_access()
meta = load_meta()
data = load_data()

st.sidebar.markdown(f\"\"\"**Rolle:** {user['role'].capitalize()}\\n**Benutzer:** {user['display']}\"\"\")
if st.sidebar.button("Logout"):
    st.session_state.clear()
    st.experimental_rerun()

# Reminder banner for Kunde
if user["role"] == "kunde":
    last = meta.get("last_upload")
    if last:
        try:
            last_dt = datetime.datetime.fromisoformat(last)
            days = (datetime.datetime.now() - last_dt).days
            if days >= REMINDER_DAYS:
                st.warning(f"Erinnerung: Sie haben seit {days} Tagen keine Bilanz hochgeladen. Bitte aktualisieren Sie Ihre Daten.")
        except Exception:
            pass
    else:
        st.info("Noch keine Bilanz hochgeladen. Bitte Daten hochladen.")

# Notifications area for Berater/Bank
if user["role"] in ["steuerberater", "bank"]:
    st.subheader("Benachrichtigungen")
    notifs = [n for n in meta.get("notifications", []) if n.get("target") == user["role"]]
    if notifs:
        for n in notifs:
            st.info(f\"{n.get('timestamp')}: {n.get('message')}\")
    else:
        st.write(\"Keine neuen Benachrichtigungen.\")

# Main tabs
tab1, tab2, tab3 = st.tabs([\"Analyse\",\"Datenverwaltung\",\"Freigaben & Logs\"])

with tab2:
    st.header(\"Datenverwaltung\")
    st.write(\"Upload: CSV, XLSX, XML oder PDF. Nach dem Upload werden die Kennzahlen automatisch berechnet und Daten gespeichert.\")
    uploaded = st.file_uploader(\"Datei hochladen\", type=[\"csv\",\"xlsx\",\"xml\",\"pdf\"]) 
    if uploaded is not None:
        try:
            fname = uploaded.name.lower()
            if fname.endswith(\".csv\"):
                df = pd.read_csv(uploaded)
            elif fname.endswith(\".xlsx\") or fname.endswith(\".xls\"):
                df = pd.read_excel(uploaded)
            elif fname.endswith(\".xml\"):
                df = parse_xml_to_df(uploaded)
            elif fname.endswith(\".pdf\"):
                df = parse_pdf_to_df(uploaded)
            else:
                st.error(\"Unbekanntes Format.\")
                df = None

            if df is not None:
                save_data(df)
                meta['last_upload'] = datetime.datetime.now().isoformat()
                # create notifications for roles if freigeben gesetzt
                if access.get('kunde',{}).get('berater'):
                    meta['notifications'].append({
                        'timestamp': datetime.datetime.now().isoformat(),
                        'target': 'steuerberater',
                        'message': f'Neue Bilanzdaten von Kunde hochgeladen: {uploaded.name}'
                    })
                if access.get('kunde',{}).get('bank'):
                    meta['notifications'].append({
                        'timestamp': datetime.datetime.now().isoformat(),
                        'target': 'bank',
                        'message': f'Neue Bilanzdaten von Kunde hochgeladen: {uploaded.name}'
                    })
                save_meta(meta)
                st.success(\"Datei eingelesen und gespeichert. Kennzahlen werden berechnet.\")
                st.subheader(\"Hochgeladene Daten (Vorschau)\")
                st.dataframe(df)
                try:
                    kpis = calculate_kpis(df)
                    st.subheader(\"Kennzahlen (Vorschau)\")
                    if 'Jahr' in kpis.columns:
                        latest = kpis.sort_values('Jahr').iloc[-1]
                        st.metric(\"Eigenkapitalquote\", f\"{(latest['Eigenkapitalquote']*100):.1f}%\" if pd.notna(latest['Eigenkapitalquote']) else \"n/a\")
                        st.metric(\"Verschuldungsgrad\", f\"{latest['Verschuldungsgrad']:.2f}x\" if pd.notna(latest['Verschuldungsgrad']) else \"n/a\")
                    st.dataframe(kpis.head(10))
                except Exception as e:
                    st.error(f\"Fehler bei KPI-Berechnung: {e}\")
        except Exception as e:
            st.error(f\"Fehler beim Einlesen: {e}\")

    persisted = load_data()
    if persisted is not None:
        st.subheader(\"Persistierte Daten\")
        st.dataframe(persisted)

with tab1:
    st.header(\"Analyse & Dashboard\")
    persisted = load_data()
    if persisted is None:
        st.info(\"Keine Daten vorhanden. Bitte unter 'Datenverwaltung' hochladen.\")
    else:
        kpis = calculate_kpis(persisted)
        st.subheader(\"Kennzahlen (pro Jahr)\")
        display_cols = [\"Jahr\",\"Bilanzsumme_final\",\"Anlagevermögen\",\"Umlaufvermögen\",\"Eigenkapital\",\"Langfristiges Fremdkapital\",\"Kurzfristiges Fremdkapital\",\"Working Capital\",\"Liquidität 1. Grades\",\"Liquidität 2. Grades\",\"Liquidität 3. Grades\",\"Eigenkapitalquote\",\"Verschuldungsgrad\",\"Anlagendeckungsgrad II\"]
        for c in display_cols:
            if c not in kpis.columns:
                kpis[c] = pd.NA
        st.dataframe(kpis[display_cols].sort_values('Jahr'))

        st.subheader(\"Verläufe\")
        try:
            chart_df = kpis.set_index('Jahr')[['Eigenkapitalquote','Fremdkapitalquote','Liquidität 3. Grades']].sort_index()
            st.line_chart(chart_df)
        except Exception:
            st.info(\"Chart konnte nicht gezeichnet werden (fehlende Werte).\")


with tab3:
    st.header(\"Freigaben & Logs\")
    if user['role']=='kunde':
        st.subheader(\"Freigaben verwalten\")
        acc = access.get('kunde',{'berater':False,'bank':False})
        ber = st.checkbox(\"Steuerberater darf Daten sehen\", value=acc.get('berater',False))
        ban = st.checkbox(\"Bank darf Daten sehen\", value=acc.get('bank',False))
        if st.button(\"Freigaben speichern\"):
            access['kunde'] = {'berater': ber, 'bank': ban}
            save_access(access)
            st.success(\"Freigaben gespeichert.\")
    else:
        st.write(\"Freigaben können nur vom Kunden verwaltet werden.\")

    st.subheader(\"System-Logs / Notifications (Admin view)\")
    meta = load_meta()
    st.write(\"Letzter Upload:\", meta.get('last_upload'))
    st.write(\"Notifications:\")
    st.json(meta.get('notifications', []))

# End
